import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Phone, BookOpen, Users, Zap, Award, Clock, MessageCircle, MapPin, Star } from "lucide-react";

/**
 * Akanksha Tutorials - Premium Landing Page
 * Design: Academic Authority with Minimalist Elegance
 * Color Scheme: Deep Red (#C41E3A), Black, White
 * Typography: Playfair Display (headlines), Poppins (body)
 */

export default function Home() {
  const handleWhatsApp = () => {
    window.open("https://wa.me/919702308940?text=Hi%20Akanksha%20Tutorials%2C%20I%20would%20like%20to%20know%20more%20about%20your%20courses.", "_blank");
  };

  const handleCall = () => {
    window.location.href = "tel:+919702308940";
  };

  const handleBookDemo = () => {
    window.open("https://wa.me/919702308940?text=I%20would%20like%20to%20book%20a%20free%20demo%20class.", "_blank");
  };

  return (
    <div className="min-h-screen bg-white text-gray-900">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-red-700 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">A</span>
            </div>
            <span className="font-playfair font-bold text-xl text-gray-900">Akanksha Tutorials</span>
          </div>
          <div className="hidden md:flex items-center gap-6">
            <a href="#curriculum" className="text-gray-700 hover:text-red-700 transition">Curriculum</a>
            <a href="#why-us" className="text-gray-700 hover:text-red-700 transition">Why Us</a>
            <a href="#testimonials" className="text-gray-700 hover:text-red-700 transition">Reviews</a>
            <a href="#locations" className="text-gray-700 hover:text-red-700 transition">Locations</a>
          </div>
          <Button 
            onClick={handleCall}
            className="bg-red-700 hover:bg-red-800 text-white"
          >
            <Phone className="w-4 h-4 mr-2" />
            Call Now
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div 
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663517414158/37VgqyMZb3oPrEBDvhjFrU/hero-gradient-PBZwGjQZSnUJ26VAMXMZua.webp')",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="absolute inset-0 bg-white/95 z-0" />
        
        <div className="container relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="inline-block">
                <span className="text-sm font-semibold text-red-700 tracking-wider">PREMIUM EDUCATION</span>
              </div>
              <h1 className="font-playfair font-bold text-5xl md:text-6xl leading-tight text-gray-900">
                Where Students Don't Just Pass — They <span className="text-red-700">Excel</span>
              </h1>
              <p className="text-lg text-gray-700 leading-relaxed">
                Mira Road's premier coaching institute for School, Degree, and Engineering students. Founded by Er. Akanksha Singh with a commitment to transforming education through personalized attention and proven methodologies.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button 
                  onClick={handleBookDemo}
                  className="bg-red-700 hover:bg-red-800 text-white text-base py-6 px-8 font-semibold"
                >
                  Book Free Demo
                </Button>
                <Button 
                  onClick={handleCall}
                  variant="outline"
                  className="border-2 border-gray-900 text-gray-900 hover:bg-gray-50 text-base py-6 px-8 font-semibold"
                >
                  <Phone className="w-5 h-5 mr-2" />
                  Call Us
                </Button>
              </div>
            </div>

            <div className="relative h-96 md:h-full">
              <div className="absolute inset-0 bg-gradient-to-br from-red-700/10 to-transparent rounded-lg" />
              <div className="flex items-center justify-center h-full">
                <div className="text-center space-y-4">
                  <div className="text-6xl">📚</div>
                  <p className="text-gray-600 font-semibold">Excellence in Education</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Bar */}
      <section className="bg-gray-50 border-y border-gray-200 py-8">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex items-center justify-center md:justify-start gap-4">
              <div className="text-3xl">⭐</div>
              <div>
                <p className="text-sm text-gray-600">Google Rating</p>
                <p className="text-2xl font-bold text-gray-900">4.8★</p>
              </div>
            </div>
            <div className="flex items-center justify-center gap-4">
              <div className="text-3xl">🏢</div>
              <div>
                <p className="text-sm text-gray-600">Branches in Mira Road</p>
                <p className="text-2xl font-bold text-gray-900">3 Locations</p>
              </div>
            </div>
            <div className="flex items-center justify-center md:justify-end gap-4">
              <div className="text-3xl">💳</div>
              <div>
                <p className="text-sm text-gray-600">Flexible Payment</p>
                <p className="text-2xl font-bold text-gray-900">0% EMI</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Curriculum Section */}
      <section id="curriculum" className="py-20 md:py-32 bg-white">
        <div className="container">
          <div className="text-center mb-16">
            <span className="text-sm font-semibold text-red-700 tracking-wider">OUR OFFERINGS</span>
            <h2 className="font-playfair font-bold text-4xl md:text-5xl mt-4 text-gray-900">
              Our Massive <span className="text-red-700">Curriculum</span>
            </h2>
            <p className="text-lg text-gray-600 mt-4 max-w-2xl mx-auto">
              Comprehensive coaching programs designed for every stage of your academic journey
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* School Card */}
            <Card className="p-8 border-2 border-gray-200 hover:border-red-700 hover:shadow-lg transition-all duration-300 group">
              <div className="w-12 h-12 bg-red-700/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-red-700 transition-colors">
                <BookOpen className="w-6 h-6 text-red-700 group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-playfair font-bold text-2xl text-gray-900 mb-3">School (1st to 10th)</h3>
              <p className="text-gray-600 mb-4">Foundation building with comprehensive coverage of all boards</p>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-gray-700">
                  <span className="w-1.5 h-1.5 bg-red-700 rounded-full" />
                  <span>SSC, CBSE, ICSE, IGCSE, IB</span>
                </div>
              </div>
            </Card>

            {/* 11th & 12th + Entrance Card */}
            <Card className="p-8 border-2 border-gray-200 hover:border-red-700 hover:shadow-lg transition-all duration-300 group">
              <div className="w-12 h-12 bg-red-700/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-red-700 transition-colors">
                <Award className="w-6 h-6 text-red-700 group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-playfair font-bold text-2xl text-gray-900 mb-3">11th & 12th + Entrance</h3>
              <p className="text-gray-600 mb-4">Specialized coaching with integrated entrance exam preparation</p>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-gray-700">
                  <span className="w-1.5 h-1.5 bg-red-700 rounded-full" />
                  <span>Science, Commerce, Arts</span>
                </div>
                <div className="flex items-center gap-2 text-gray-700">
                  <span className="w-1.5 h-1.5 bg-red-700 rounded-full" />
                  <span>MH-CET, JEE-MAINS, NEET</span>
                </div>
                <div className="flex items-center gap-2 text-gray-700">
                  <span className="w-1.5 h-1.5 bg-red-700 rounded-full" />
                  <span>Integrated Science Course</span>
                </div>
              </div>
            </Card>

            {/* Degree Card */}
            <Card className="p-8 border-2 border-gray-200 hover:border-red-700 hover:shadow-lg transition-all duration-300 group">
              <div className="w-12 h-12 bg-red-700/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-red-700 transition-colors">
                <Users className="w-6 h-6 text-red-700 group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-playfair font-bold text-2xl text-gray-900 mb-3">Degree Courses</h3>
              <p className="text-gray-600 mb-4">Professional degree programs with industry-relevant curriculum</p>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-gray-700">
                  <span className="w-1.5 h-1.5 bg-red-700 rounded-full" />
                  <span>BSC-IT, CS, BMS, BBI, BBA, BAF</span>
                </div>
                <div className="flex items-center gap-2 text-gray-700">
                  <span className="w-1.5 h-1.5 bg-red-700 rounded-full" />
                  <span>B.COM, BMM</span>
                </div>
              </div>
            </Card>

            {/* Engineering & Diploma Card */}
            <Card className="p-8 border-2 border-gray-200 hover:border-red-700 hover:shadow-lg transition-all duration-300 group">
              <div className="w-12 h-12 bg-red-700/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-red-700 transition-colors">
                <Zap className="w-6 h-6 text-red-700 group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-playfair font-bold text-2xl text-gray-900 mb-3">Engineering & Diploma</h3>
              <p className="text-gray-600 mb-4">Specialized training for technical disciplines and certifications</p>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-gray-700">
                  <span className="w-1.5 h-1.5 bg-red-700 rounded-full" />
                  <span>Mechanical, EXTC, IT, CS, Civil</span>
                </div>
                <div className="flex items-center gap-2 text-gray-700">
                  <span className="w-1.5 h-1.5 bg-red-700 rounded-full" />
                  <span>Electrical, Automobile, Chemical</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section id="why-us" className="py-20 md:py-32 bg-gray-50">
        <div className="container">
          <div className="text-center mb-16">
            <span className="text-sm font-semibold text-red-700 tracking-wider">OUR ADVANTAGES</span>
            <h2 className="font-playfair font-bold text-4xl md:text-5xl mt-4 text-gray-900">
              Why Choose <span className="text-red-700">Akanksha Tutorials</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* AC Classrooms */}
            <div className="flex gap-6 p-8 bg-white rounded-lg border border-gray-200 hover:border-red-700 transition-colors">
              <div className="flex-shrink-0">
                <div className="w-14 h-14 bg-red-700/10 rounded-lg flex items-center justify-center">
                  <span className="text-2xl">❄️</span>
                </div>
              </div>
              <div>
                <h3 className="font-playfair font-bold text-xl text-gray-900 mb-2">AC Classrooms</h3>
                <p className="text-gray-600">Comfortable, climate-controlled learning environment for optimal focus and concentration</p>
              </div>
            </div>

            {/* 0% EMI Fees */}
            <div className="flex gap-6 p-8 bg-white rounded-lg border border-gray-200 hover:border-red-700 transition-colors">
              <div className="flex-shrink-0">
                <div className="w-14 h-14 bg-red-700/10 rounded-lg flex items-center justify-center">
                  <span className="text-2xl">💳</span>
                </div>
              </div>
              <div>
                <h3 className="font-playfair font-bold text-xl text-gray-900 mb-2">0% Interest EMI</h3>
                <p className="text-gray-600">Flexible payment options with zero-interest EMI to make quality education accessible</p>
              </div>
            </div>

            {/* Personalized Attention */}
            <div className="flex gap-6 p-8 bg-white rounded-lg border border-gray-200 hover:border-red-700 transition-colors">
              <div className="flex-shrink-0">
                <div className="w-14 h-14 bg-red-700/10 rounded-lg flex items-center justify-center">
                  <span className="text-2xl">👥</span>
                </div>
              </div>
              <div>
                <h3 className="font-playfair font-bold text-xl text-gray-900 mb-2">Personalized Attention</h3>
                <p className="text-gray-600">Small batch sizes ensuring individual focus and customized learning paths for each student</p>
              </div>
            </div>

            {/* Doubt-Clearing Sessions */}
            <div className="flex gap-6 p-8 bg-white rounded-lg border border-gray-200 hover:border-red-700 transition-colors">
              <div className="flex-shrink-0">
                <div className="w-14 h-14 bg-red-700/10 rounded-lg flex items-center justify-center">
                  <span className="text-2xl">❓</span>
                </div>
              </div>
              <div>
                <h3 className="font-playfair font-bold text-xl text-gray-900 mb-2">Doubt-Clearing Sessions</h3>
                <p className="text-gray-600">Regular one-on-one sessions to clarify concepts and strengthen understanding</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 md:py-32 bg-white">
        <div className="container">
          <div className="text-center mb-16">
            <span className="text-sm font-semibold text-red-700 tracking-wider">SUCCESS STORIES</span>
            <h2 className="font-playfair font-bold text-4xl md:text-5xl mt-4 text-gray-900">
              Wall of <span className="text-red-700">Love</span>
            </h2>
            <p className="text-lg text-gray-600 mt-4">Hear from our successful students and their transformative experiences</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <Card className="p-8 border border-gray-200 hover:shadow-lg transition-all duration-300">
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-red-700 text-red-700" />
                ))}
              </div>
              <p className="text-gray-700 mb-6 leading-relaxed">
                "The crash course was absolutely game-changing! I passed in my first attempt with flying colors. The teaching style is so engaging and the doubt-clearing sessions were incredibly helpful."
              </p>
              <div className="border-t border-gray-200 pt-4">
                <p className="font-semibold text-gray-900">Priya Sharma</p>
                <p className="text-sm text-gray-600">JEE-MAINS Aspirant</p>
              </div>
            </Card>

            {/* Testimonial 2 */}
            <Card className="p-8 border border-gray-200 hover:shadow-lg transition-all duration-300">
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-red-700 text-red-700" />
                ))}
              </div>
              <p className="text-gray-700 mb-6 leading-relaxed">
                "Akanksha Tutorials transformed my understanding of complex concepts. The personalized attention and structured curriculum made all the difference. Highly recommended!"
              </p>
              <div className="border-t border-gray-200 pt-4">
                <p className="font-semibold text-gray-900">Arjun Patel</p>
                <p className="text-sm text-gray-600">NEET Aspirant</p>
              </div>
            </Card>

            {/* Testimonial 3 */}
            <Card className="p-8 border border-gray-200 hover:shadow-lg transition-all duration-300">
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-red-700 text-red-700" />
                ))}
              </div>
              <p className="text-gray-700 mb-6 leading-relaxed">
                "The faculty here genuinely cares about student success. The 0% EMI option made it affordable, and the results speak for themselves. I couldn't have asked for better coaching!"
              </p>
              <div className="border-t border-gray-200 pt-4">
                <p className="font-semibold text-gray-900">Anjali Desai</p>
                <p className="text-sm text-gray-600">Commerce Stream Student</p>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-red-700 to-red-800">
        <div className="container text-center">
          <h2 className="font-playfair font-bold text-4xl md:text-5xl text-white mb-6">
            Join Thousands of Successful Students
          </h2>
          <p className="text-xl text-red-100 mb-8 max-w-2xl mx-auto">
            Your journey to excellence starts here. Connect with us today and take the first step towards academic success.
          </p>
          <Button 
            onClick={handleWhatsApp}
            className="bg-white text-red-700 hover:bg-gray-100 text-lg py-6 px-10 font-semibold"
          >
            <MessageCircle className="w-5 h-5 mr-2" />
            WhatsApp Us Now
          </Button>
        </div>
      </section>

      {/* Footer & Locations */}
      <footer id="locations" className="bg-gray-900 text-white py-16">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 mb-12">
            <div>
              <div className="flex items-center gap-2 mb-6">
                <div className="w-10 h-10 bg-red-700 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-lg">A</span>
                </div>
                <span className="font-playfair font-bold text-xl">Akanksha Tutorials</span>
              </div>
              <p className="text-gray-400 mb-6">
                Premier coaching institute dedicated to transforming education and empowering students to achieve their dreams.
              </p>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-red-700" />
                <a href="tel:+919702308940" className="hover:text-red-700 transition">
                  +91 9702308940
                </a>
              </div>
            </div>

            <div>
              <h3 className="font-playfair font-bold text-2xl mb-6">Our Branches</h3>
              <div className="space-y-4">
                <div className="flex gap-3">
                  <MapPin className="w-5 h-5 text-red-700 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold">Shanti Park</p>
                    <p className="text-gray-400 text-sm">Mira Road, Mumbai</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <MapPin className="w-5 h-5 text-red-700 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold">Gokul Village</p>
                    <p className="text-gray-400 text-sm">Mira Road, Mumbai</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <MapPin className="w-5 h-5 text-red-700 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold">Kanakia</p>
                    <p className="text-gray-400 text-sm">Mira Road, Mumbai</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2026 Akanksha Tutorials. All rights reserved. Founded by Er. Akanksha Singh.
            </p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-red-700 transition text-sm">Privacy Policy</a>
              <a href="#" className="text-gray-400 hover:text-red-700 transition text-sm">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
